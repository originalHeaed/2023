package cn.bugstack.springframework.test.bean;

public interface IUserDao {

    String queryUserName(String uId);

}
