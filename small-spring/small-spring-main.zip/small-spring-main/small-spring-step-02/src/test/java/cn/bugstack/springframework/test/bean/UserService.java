package cn.bugstack.springframework.test.bean;

/**
 * 作者：DerekYRC https://github.com/DerekYRC/mini-spring
 */
public class UserService {

    public void queryUserInfo(){
        System.out.println("查询用户信息");
    }

}
